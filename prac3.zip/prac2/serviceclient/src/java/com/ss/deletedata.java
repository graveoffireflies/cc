/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ss;

/**
 *
 * @author admin
 */
public class deletedata {
    public static void deldata(String id){ 
        String a = id; 
        data ob = new data();         
              ob.remove(a); 
        System.out.println("Data is deleted."); 
    }

}
